import Home from "./home";
import Faqs from "./faqs";

export { Home, Faqs };
