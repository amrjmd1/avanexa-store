// import React, { memo, useEffect, useState } from "react";
// import { Modal, View } from "react-native";
// import { get_categorise } from "./../../../services";

// const Filter = memo(() => {
//   const [filters_data, setFilters] = useState([]);

//   useEffect(() => {
//     get_categorise().then((data) => setFilters(data || []));
//   }, []);

//   return (
//     <Modal transparent>
//       <View
//         style={{
//           flex: 1,
//           backgroundColor: "#fff",
//         }}
//       >

//       </View>
//     </Modal>
//   );
// });

// export default Filter;
