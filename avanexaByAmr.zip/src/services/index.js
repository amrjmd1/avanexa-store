import get_products from "./products";
import get_faqs from "./faqs";
import get_categorise from "./category";

export { get_products, get_faqs, get_categorise };
