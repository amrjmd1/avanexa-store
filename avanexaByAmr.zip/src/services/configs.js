export const BASE_URL = "https://avanexa.in/brandmax/api/";
